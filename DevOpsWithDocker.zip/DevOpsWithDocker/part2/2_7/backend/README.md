# Backend for kurkkumopo exercise

Flask backend running in port `5000`. Requires a model created by `ml-kurkkumopo-training` at `src/model`
