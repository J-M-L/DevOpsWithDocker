# Training of the model for kurkkumopo exercise

Downloads images to `/imgs` folder and creates CSVs to for generated image URI:s to `/data` folder. Creates a model to `/model` folder.
