# Frontend for kurkkumopo exercise

Runs in port `3000` and connects to backend running at port `5000`
